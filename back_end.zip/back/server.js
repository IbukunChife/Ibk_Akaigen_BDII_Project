const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');
const requireDir = require('require-dir');

//Iniciando o App
const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());
app.use(cookieParser());

//Iniciando e Testando o DB
const mongo_uri = 'mongodb://localhost:27017/didier';
mongoose.connect(mongo_uri, { useNewUrlParser: true }, function(err) {
  if (err) {
    throw err;
  } else {
    console.log(`Successfully connected to ${mongo_uri}`);
  }
});

requireDir('./src/models');

//"use" aceita todos os tipos de requisição
app.use('/api', require("./src/routes"));

const PORT = "3001";
app.listen(PORT, () => {
	console.log('Running Server on Port '+PORT);
});