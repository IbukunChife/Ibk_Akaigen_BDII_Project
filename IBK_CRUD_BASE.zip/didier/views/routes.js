const express = require('express');
const routes = express.Router();
const mongoose = require('mongoose');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

const Product = mongoose.model('Product');


//HOME
routes.get('/', (req, res) => {
    Product.find(function(err, products) {
        if (err) {
            console.log(err);
        } else {
            res.render('pages/home', { 
                user: req.user,
                products: products 
            });
        }
    });
})

//CADASTRAR PRODUTO
routes.get('/produto/cadastrar', (req, res) => {
    res.render('pages/cadastrarProduto', { 
        user: req.user
    });
})

//LOGIN
routes.get('/login', (req, res) => {
    res.render('pages/login', { 
        user: req.user
    });
})
routes.post('/login', 
  passport.authenticate('local', { failureRedirect: '/login' }),
  function(req, res) {
    res.redirect('/');
});

//LOGOUT
routes.get('/logout', isLoggedIn, (req, res) => {
    req.logout();
    res.redirect('/');
});

//Cart
routes.get('/cart',
  require('connect-ensure-login').ensureLoggedIn(),
  function(req, res){
    let cart = req.user.cart;
    let total=0;
    for (let i=0;i<cart.length;i++){
        total = total + (cart[i].price * cart[i].amout);
    }
    //res.json(total);
    res.render('pages/cart', { 
        user: req.user,
       totalCart: total 
    });
});

//REGISTER
//HOME
routes.get('/register', (req, res) => {
    res.render('pages/register', { 
        user: req.user
    });
})

//PROFILE
routes.get('/profile',
  require('connect-ensure-login').ensureLoggedIn(),
  function(req, res){
    res.render('pages/profile', { user: req.user });
});


module.exports = routes;

//route middleware to ensure user is logged in
function isLoggedIn(req, res, next) {
    if (req.isAuthenticated())
        return next();
    res.status(400).json({
        'message': 'access denied'
    });
}