const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const path = require('path');
const mongoose = require('mongoose');

const passport = require('passport');
const flash = require('connect-flash');
const session = require('express-session');
const app = express();

// Passport Config
require('./config/passport')(passport);

//config DataBase Mongo
const db = require('./config/keys').MongoURI;

//EJS
app.use(expressLayouts);
app.set('view engine', 'ejs');

// Express session
app.use(
    session({
        secret: 'secret',
        resave: true,
        saveUninitialized: true,
    })
);

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Connect flash
app.use(flash());

// Global variables
app.use(function(req, res, next) {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    next();
});

//Bodyparse
app.use(express.urlencoded({ extended: false }));

//Middleware static files
app.use(express.static(path.join(__dirname, 'public')));

//Routes for requisição
app.use('/', require('./routes/routes'));

//Connection mongoose
mongoose.Promise = global.Promise;
mongoose
    .connect(db, { useNewUrlParser: true })
    .then(() => console.log('MongoDB Connected'))
    .catch(err => console.log(err));

const PORT = 4010;
app.listen(PORT, console.log(`Server started on port ${PORT}`));

// //Routes
// app.use('/', require('./routes/index'));
// app.use('/users', require('./routes/users'));
// app.use('/product', require('./routes/product'));

// app.use('/cart', require('./routes/index'));
// app.use('/category', require('./routes/index'));
// app.use('/productInfo', require('./routes/index'));
// app.use('/contact', require('./routes/index'));
// app.use('/logo', require('./routes/neoj'));

// //Connection Neo4j
// const graphdb = new neo4j.GraphDatabase('http://ibukun:123456@localhost:7474');

// const neo4j = require('neo4j-driver').v1;
//config DataBase Neo4j
// const dbs = require('./config/Neo4j').Neo4jURI;
// const us = require('./config/Neo4j').User;
// const ps = require('./config/Neo4j').Pass;
//Neo4j connection
// const Neo4jdriver = neo4j.driver(dbs, neo4j.auth.basic(us, ps));
// const Neo4jsession = Neo4jdriver.session();