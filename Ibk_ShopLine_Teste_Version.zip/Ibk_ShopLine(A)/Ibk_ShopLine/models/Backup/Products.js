const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    title: {
        type: String,
        require: true,
        trim: true,
    },

    slug: {
        //ex: video game = video-game
        type: String,
        require: true,
        trim: true,
        index: true,
        unique: true,
    },

    description: {
        type: String,
        require: true,
    },

    price: {
        type: Number,
        require: true,
    },

    active: {
        type: Boolean,
        require: true,
        defaut: true,
    },

    tags: [{
        type: String,
        require: true,
    }, ],

    imagens: {
        type: String,
        require: true,
        trim: true,
    },
});

ProductSchema.set('graphability', true);

const Products = mongoose.model('Products', ProductSchema);
module.exports = Products;