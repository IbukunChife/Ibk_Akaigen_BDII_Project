const mongoose = require('mongoose');

const CarinhoUserSchema = new mongoose.Schema({
    title: String,
    quantidade: Number,
    preco: Number,
    data: {
        type: Date,
        default: Date.now,
    },
});

const ProductCompradoUserSchema = new mongoose.Schema({
    title: String,
    quantidade: Number,
    preco: Number,
    data: {
        type: Date,
        default: Date.now,
    },
});

const UserSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },

    email: {
        type: String,
        unique: true,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
    date: {
        type: Date,
        default: Date.now,
    },

    carinho: [CarinhoUserSchema],
    comprados: [ProductCompradoUserSchema],
});

UserSchema.set('graphability', true);

const User = mongoose.model('User', UserSchema);
module.exports = User;