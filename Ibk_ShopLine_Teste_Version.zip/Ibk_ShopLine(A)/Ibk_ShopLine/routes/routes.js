const express = require('express');
const routes = express.Router();
// const withAuth = require('./middleware');

const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');
const UserController = require('../controllers/UserController');
const ProductController = require('../controllers/ProductController');
// const ProductPurchasedController = require('./controllers/ProductPurchasedController');

routes.get('/', forwardAuthenticated, ProductController.index);

//UserController
routes.get('/user', ensureAuthenticated, UserController.index);
routes.get('/user/:id', ensureAuthenticated, UserController.show);
routes.post('/user/register', ensureAuthenticated, UserController.store);
routes.put('/user/:id', ensureAuthenticated, UserController.update);
routes.delete('/user/:id', ensureAuthenticated, UserController.destroy);

routes.put('/user_cart/:id/add_cart/:product', ensureAuthenticated, UserController.addCart);
routes.put('/user_cart/:id/rem_cart/:product', ensureAuthenticated, UserController.remCart);
routes.put('/finalizar_compra/:id', ensureAuthenticated, UserController.finalizarCompra);

//ProductController
routes.get('/product', ProductController.index);
routes.get('/product/:id', ProductController.show);
routes.post('/product', ProductController.store);
routes.put('/product/:id', ProductController.update);
routes.delete('/product/:id', ProductController.destroy);

// //ProductPurchasedController
// routes.get('/product_purchased', ProductPurchasedController.index);
// routes.get('/product_purchased/:id', ProductPurchasedController.show);
// routes.post('/product_purchased', ProductPurchasedController.store);
// routes.put('/product_purchased/:id', ProductPurchasedController.update);
// routes.delete('/product_purchased/:id', ProductPurchasedController.destroy);

module.exports = routes;