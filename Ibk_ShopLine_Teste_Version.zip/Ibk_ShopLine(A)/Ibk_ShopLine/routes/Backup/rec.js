const express = require('express');
const router = express.Router();
// const section = require('../app');

router.get('/category', (req, res) => {
    res.render('category');
});

// router.get('/logo', (req, res) => {
//     // res.render('test');
//     // // });
//     section
//         .run('MATCH (n:`Usuários`) RETURN n LIMIT 25')
//         .then(function(result) {
//             var usuarioArr = [];

//             result.records.forEach(function(p) {
//                 usuarioArr.push({
//                     id: p._fields[0].identity.low,
//                     name: p._fields[0].identity.name,
//                     genero: p._fields[0].identity.genero,
//                 });
//                 // console.log(p._fields[0].properties);
//             });
//             res.render('test', {
//                 user: usuarioArr,
//             });
//         })
//         .catch(function(err) {
//             console.log(err);
//         });
// });

module.exports = router;