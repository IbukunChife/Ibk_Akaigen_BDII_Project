const express = require('express');
const router = express.Router();
// const bcrypt = require('bcryptjs');

// Load Produto model
const Products = require('../models/Products');
// const ProductsNeo4j = require('../modelsNeo4j/Products');

// Register Page
router.get('/cadastrar', (req, res) => res.render('cadastrarProduct'));

// Register
router.post('/cadastrar', (req, res) => {
    const { title, slug, description, price, active, tags, imagens } = req.body;
    let errors = [];

    if (!title || !slug || !description || !price || !active || !tags || !imagens) {
        errors.push({ msg: 'Por favor, insira todos os campos' });
    }

    if (description.length < 3) {
        errors.push({ msg: 'A descrição deve ter pelo menos 3 caracteres' });
    }

    if (errors.length > 0) {
        res.render('cadastarProduct', {
            errors,
            title,
            slug,
            description,
            price,
            active,
            tags,
            imagens,
        });
    } else {
        Products.findOne({ title: title }).then(produto => {
            if (produto) {
                errors.push({ msg: 'Produto já existe' });
                res.render('cadastarProduct', {
                    errors,
                    title,
                    slug,
                    description,
                    price,
                    active,
                    tags,
                    imagens,
                });
            } else {
                const newProduct = new Products({
                    title,
                    slug,
                    description,
                    price,
                    active,
                    tags,
                    imagens,
                });

                newProduct
                    .save()
                    .then(produto => {
                        req.flash('sucesso_msg', 'Produto cadastrado com sucesso');
                        res.redirect('/');
                    })
                    .catch(err => console.log(err));

                // bcrypt.genSalt(10, (err, salt) => {
                //     bcrypt.hash(newProduct.title, salt, (err, hash) => {
                //         if (err) throw err;
                //         newProduct.title = hash;

                //     });
                // });
            }
        });
    }
});

// //arrumar isso depois
// // Login
// router.post('/', (req, res, next) => {
//     passport.authenticate('local', {
//         successRedirect: '/dashboard',
//         failureRedirect: '/',
//         failureFlash: true
//     })(req, res, next);
// });

// // Logout
// router.get('/logout', (req, res) => {
//     req.logout();
//     req.flash('success_msg', 'Você está desconectado');
//     res.redirect('/');
// });

module.exports = router;