const express = require('express');
const router = express.Router();
const Products = require('../models/Products');
const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');

// Welcome Page
router.get('/', forwardAuthenticated, (req, res) => {
    Products.find(function(err, products) {
        if (err) {
            console.log(err);
        } else {
            res.render('principal', { products: products });
        }
    });
});

// Dashboard
router.get('/dashboard', ensureAuthenticated, (req, res) => {
    res.render('/dashboard', {
        user: req.user,
    });
});

router.get('/cart', ensureAuthenticated, (req, res) => {
    res.render('cart', {
        user: req.user,
    });
});

// router.get('/category', (req, res) => {
//     res.render('category');
// });

router.get('/productInfo', (req, res) => {
    res.render('product');
});

router.get('/contact', (req, res) => {
    res.render('contact');
});

module.exports = router;