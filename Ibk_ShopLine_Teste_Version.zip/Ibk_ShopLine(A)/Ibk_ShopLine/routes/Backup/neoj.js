const express = require('express');
const router = express.Router();
const neo4j = require('neo4j-driver').v1;
const dbs = require('../config/Neo4j').Neo4jURI;
const us = require('../config/Neo4j').User;
const ps = require('../config/Neo4j').Pass;
const Neo4jdriver = neo4j.driver(dbs, neo4j.auth.basic(us, ps));
const Neo4jsession = Neo4jdriver.session();
const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');

router.get('/', (req, res) => {
    // res.render('test');
    // // });
    Neo4jsession.run('MATCH (n:`Usuários`) RETURN n LIMIT 25')
        .then(function(result) {
            var usuarioArr = [];
            result.records.forEach(function(p) {
                usuarioArr.push({
                    id: p._fields[0].identity.low,
                    name: p._fields[0].properties.name,
                    genero: p._fields[0].properties.genero,
                });
                // console.log(p._fields[0].properties);
            });
            res.render('logo', {
                user: usuarioArr,
            });
        })
        .catch(function(err) {
            console.log(err);
        });
});

module.exports = router;