const express = require('express');
const routes = express.Router();
// const withAuth = require('./middleware');
const passport = require('passport');
const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');
const UserController = require('../controllers/UserController');
const ProductController = require('../controllers/ProductController');
// const ProductPurchasedController = require('./controllers/ProductPurchasedController');

routes.get('/', forwardAuthenticated, ProductController.index);

//UserController CRUD
routes.get('/user', ensureAuthenticated, UserController.index);
routes.get('/user/:id', ensureAuthenticated, UserController.show);
routes.post('/user', UserController.store);
routes.put('/user/:id', ensureAuthenticated, UserController.update);
routes.delete('/user/:id', ensureAuthenticated, UserController.destroy);

routes.put('/user_cart/:id/add_cart/:product', ensureAuthenticated, UserController.addCart);
routes.put('/user_cart/:id/rem_cart/:product', ensureAuthenticated, UserController.remCart);
routes.put('/finalizar_compra/:id', ensureAuthenticated, UserController.finalizarCompra);

//ProductController
routes.get('/product', ProductController.index);
routes.get('/product/:id', ProductController.show);
routes.post('/product', ProductController.store);
routes.put('/product/:id', ProductController.update);
routes.delete('/product/:id', ProductController.destroy);

//Manipulation User
// Login Page
routes.get('/login', forwardAuthenticated, (req, res) => res.render('login'));

// Register Page
routes.get('/register', forwardAuthenticated, (req, res) => res.render('register'));

// Dashboard
routes.get('/dashboard', ensureAuthenticated, (req, res) => {
    res.render('/dashboard', {
        user: req.user,
    });
});
// Carinho
routes.get('/cart', ensureAuthenticated, (req, res) => {
    res.render('cart', {
        user: req.user,
    });
});
// Admin
routes.get('/admin', ensureAuthenticated, (req, res) => {
    res.render('admin', {
        user: req.user,
    });
});

// // Login
// routes.post('/login', (req, res, next) => {
//     passport.authenticate('local',{
//         successRedirect: '/cart',
//         failureRedirect: '/login',
//         failureFlash: true,
//     })(req, res, next);
// });

// Login
routes.post('/login', (req, res, next) => {
    passport.authenticate('local', function(err, user, info) {
        if (user.isAdmin) {
            console.log('admin masta ' + user);
            res.redirect('/routes/routes/admin');
            // res.render('admin', { user: user });
        } else {
            console.log('user masta ' + user);
            res.render('cart', { user: user });
        }
    })(req, res, next);
});

// // Register
// router.post('/register', (req, res) => {
//     const { name, email, password, password2 } = req.body;
//     let errors = [];

//     if (!name || !email || !password || !password2) {
//         errors.push({ msg: 'Please enter all fields' });
//     }

//     if (password != password2) {
//         errors.push({ msg: 'Passwords do not match' });
//     }

//     if (password.length < 6) {
//         errors.push({ msg: 'Password must be at least 6 characters' });
//     }

//     if (errors.length > 0) {
//         res.render('register', {
//             errors,
//             name,
//             email,
//             password,
//             password2,
//         });
//     } else {
//         User.findOne({ email: email }).then(user => {
//             if (user) {
//                 errors.push({ msg: 'Email already exists' });
//                 res.render('register', {
//                     errors,
//                     name,
//                     email,
//                     password,
//                     password2,
//                 });
//             } else {
//                 const newUser = new User({
//                     name,
//                     email,
//                     password,
//                 });

//                 bcrypt.genSalt(10, (err, salt) => {
//                     bcrypt.hash(newUser.password, salt, (err, hash) => {
//                         if (err) throw err;
//                         newUser.password = hash;
//                         newUser
//                             .save()
//                             .then(user => {
//                                 req.flash('sucesso_msg', 'login cadastrado com sucesso');
//                                 console.log('ID do nó: ' + user._node_id);
//                                 User.getNode(function(err, node) {
//                                     if (err) {
//                                         console.log(err);
//                                     } else {
//                                         console.log('Nó: ' + node); // prints the node
//                                     }
//                                 });
//                                 res.redirect('/users/login');
//                             })
//                             .catch(err => console.log(err));
//                     });
//                 });
//             }
//         });
//     }
// });

// Logout
routes.get('/logout', (req, res) => {
    req.logout();
    req.flash('success_msg', 'Você está desconectado');
    res.redirect('/');
});

// //ProductPurchasedController
// routes.get('/product_purchased', ProductPurchasedController.index);
// routes.get('/product_purchased/:id', ProductPurchasedController.show);
// routes.post('/product_purchased', ProductPurchasedController.store);
// routes.put('/product_purchased/:id', ProductPurchasedController.update);
// routes.delete('/product_purchased/:id', ProductPurchasedController.destroy);

routes.get('/user/login');

module.exports = routes;