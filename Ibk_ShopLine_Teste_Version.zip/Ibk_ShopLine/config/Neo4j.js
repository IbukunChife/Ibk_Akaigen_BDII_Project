module.exports = {
    Neo4jURI: 'bolt://localhost',
    User: 'ibukun',
    Pass: '123456',
};

// module.exports = {
//     Neo4jURI: 'bolt://ebony-divide-lydia-grey.graphstory.services:7687',
//     User: 'Ibukun',
//     Pass: '4kPDXcFB3k99GEUwRSYStawz',
// };