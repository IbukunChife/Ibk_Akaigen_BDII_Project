// module.exports = {
//     MongoURI: 'mongodb+srv://larissa:larissa123@cluster0-6bp3d.mongodb.net/test?retryWrites=true'
// }
module.exports = {
    MongoURI: 'mongodb://localhost:27017/ShopLine',
};